# Projet Nikkei 225 : version finale

Cette archive contient tout le projet, sauf le site de présentation et les données brutes :
- `notebooks/` : tous les notebooks, exécutés (le 06 avec ses scripts, ses figures et son README) ;
- `src/`, `app/`, `tests/` : le code, l'API et les tests ;
- `data/2_construites/`, `data/3_modele/` : les tables mensuelles et les tables de modélisation ;
- `runs/` : journaux des essais, modèles, décisions figées, évaluations et résultats des trois étapes ;
- `figures/`, `report/` : les figures et le rapport.

Les données brutes (`data/1_brutes/`) ne sont pas incluses : elles se retéléchargent avec les notebooks 00a et 00b, et les
exports Bloomberg ne peuvent pas être redistribués. Les notebooks se lisent tels quels, sorties comprises ; pour les
réexécuter, voir le README.md (installation, puis python -m pytest -q).
